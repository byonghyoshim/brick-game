import asyncio
import os
import random
import sys

import pygame

WIDTH, HEIGHT = 800, 400
TOP_BAR = 40

PADDLE_WIDTH = 100
PADDLE_HEIGHT = 12
PADDLE_Y = HEIGHT - 30
PADDLE_SPEED = 8

BALL_RADIUS = 8
BALL_SPEED = 3

BRICK_ROWS = 5
BRICK_COLS = 12
BRICK_MARGIN = 4
BRICK_AREA_TOP = TOP_BAR + 20
BRICK_AREA_HEIGHT = 120
BRICK_WIDTH = (WIDTH - BRICK_MARGIN * (BRICK_COLS + 1)) // BRICK_COLS
BRICK_HEIGHT = (BRICK_AREA_HEIGHT - BRICK_MARGIN * (BRICK_ROWS + 1)) // BRICK_ROWS

BG = (20, 24, 36)
WHITE = (240, 240, 240)
PADDLE_COLOR = (200, 220, 255)
BALL_COLOR = (255, 230, 120)
BRICK_COLORS = [
    (231, 76, 60),
    (230, 126, 34),
    (241, 196, 15),
    (46, 204, 113),
    (52, 152, 219),
]

PHOTO_PATH = "my_photo.jpg"
AUTHOR_NAME = "Made by Byonghyo"


class Brick:
    def __init__(self, x, y, color):
        self.rect = pygame.Rect(x, y, BRICK_WIDTH, BRICK_HEIGHT)
        self.color = color
        self.alive = True


class Game:
    def __init__(self):
        self.screen = pygame.display.set_mode((WIDTH, HEIGHT))
        pygame.display.set_caption("Brick Breaker")
        self.clock = pygame.time.Clock()
        self.font = pygame.font.SysFont("arial", 22, bold=True)
        self.big_font = pygame.font.SysFont("arial", 48, bold=True)
        self.small_font = pygame.font.SysFont("arial", 18)
        self.bg_image = None
        self.bg_offset = (0, 0)
        if os.path.exists(PHOTO_PATH):
            try:
                img = pygame.image.load(PHOTO_PATH).convert()
                iw, ih = img.get_size()
                scale = max(WIDTH / iw, HEIGHT / ih)
                new_size = (int(iw * scale), int(ih * scale))
                self.bg_image = pygame.transform.smoothscale(img, new_size)
                self.bg_offset = ((WIDTH - new_size[0]) // 2,
                                  (HEIGHT - new_size[1]) // 2)
            except pygame.error:
                self.bg_image = None
        self.touch_x = None
        self.reset()

    def reset(self):
        self.score = 0
        self.game_over = False
        self.won = False
        self.paddle = pygame.Rect(
            (WIDTH - PADDLE_WIDTH) // 2, PADDLE_Y,
            PADDLE_WIDTH, PADDLE_HEIGHT
        )
        self.ball_x = WIDTH / 2
        self.ball_y = HEIGHT / 2 + 40
        angle = random.uniform(-0.6, 0.6)
        self.ball_vx = BALL_SPEED * (1 if random.random() < 0.5 else -1) * (0.6 + abs(angle))
        self.ball_vy = BALL_SPEED
        self.bricks = self.build_bricks()
        self.start_time = pygame.time.get_ticks()
        self.start_delay = 3000

    def build_bricks(self):
        bricks = []
        for row in range(BRICK_ROWS):
            for col in range(BRICK_COLS):
                x = BRICK_MARGIN + col * (BRICK_WIDTH + BRICK_MARGIN)
                y = BRICK_AREA_TOP + BRICK_MARGIN + row * (BRICK_HEIGHT + BRICK_MARGIN)
                bricks.append(Brick(x, y, BRICK_COLORS[row]))
        return bricks

    def update(self):
        if self.game_over or self.won:
            return

        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT] or keys[pygame.K_a]:
            self.paddle.x -= PADDLE_SPEED
        if keys[pygame.K_RIGHT] or keys[pygame.K_d]:
            self.paddle.x += PADDLE_SPEED

        if self.touch_x is not None:
            target_x = self.touch_x - PADDLE_WIDTH // 2
            diff = target_x - self.paddle.x
            self.paddle.x += int(diff * 0.35)

        self.paddle.x = max(0, min(WIDTH - PADDLE_WIDTH, self.paddle.x))

        elapsed = pygame.time.get_ticks() - self.start_time
        if elapsed < self.start_delay:
            return

        self.ball_x += self.ball_vx
        self.ball_y += self.ball_vy

        if self.ball_x - BALL_RADIUS <= 0:
            self.ball_x = BALL_RADIUS
            self.ball_vx = abs(self.ball_vx)
        elif self.ball_x + BALL_RADIUS >= WIDTH:
            self.ball_x = WIDTH - BALL_RADIUS
            self.ball_vx = -abs(self.ball_vx)

        if self.ball_y - BALL_RADIUS <= TOP_BAR:
            self.ball_y = TOP_BAR + BALL_RADIUS
            self.ball_vy = abs(self.ball_vy)

        ball_rect = pygame.Rect(
            self.ball_x - BALL_RADIUS, self.ball_y - BALL_RADIUS,
            BALL_RADIUS * 2, BALL_RADIUS * 2
        )

        if self.ball_vy > 0 and ball_rect.colliderect(self.paddle):
            self.ball_y = self.paddle.top - BALL_RADIUS
            self.ball_vy = -abs(self.ball_vy)
            offset = (self.ball_x - self.paddle.centerx) / (PADDLE_WIDTH / 2)
            offset = max(-1, min(1, offset))
            self.ball_vx = BALL_SPEED * offset * 1.2
            speed = (self.ball_vx ** 2 + self.ball_vy ** 2) ** 0.5
            scale = BALL_SPEED * 1.2 / speed if speed > 0 else 1
            self.ball_vx *= scale
            self.ball_vy *= scale

        for brick in self.bricks:
            if not brick.alive:
                continue
            if ball_rect.colliderect(brick.rect):
                brick.alive = False
                self.score += 10
                prev_x = self.ball_x - self.ball_vx
                if prev_x < brick.rect.left or prev_x > brick.rect.right:
                    self.ball_vx = -self.ball_vx
                else:
                    self.ball_vy = -self.ball_vy
                break

        if self.ball_y - BALL_RADIUS > HEIGHT:
            self.game_over = True

        if all(not b.alive for b in self.bricks):
            self.won = True

    def draw(self):
        self.screen.fill(BG)
        if self.bg_image is not None:
            self.screen.blit(self.bg_image, self.bg_offset)
            overlay = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
            overlay.fill((0, 0, 0, 165))
            self.screen.blit(overlay, (0, 0))

        pygame.draw.rect(self.screen, (10, 14, 24), (0, 0, WIDTH, TOP_BAR))
        score_text = self.font.render(f"Score: {self.score}", True, WHITE)
        self.screen.blit(score_text, (12, 9))
        author_text = self.font.render(AUTHOR_NAME, True, WHITE)
        self.screen.blit(author_text, (WIDTH - author_text.get_width() - 12, 9))

        for brick in self.bricks:
            if brick.alive:
                pygame.draw.rect(self.screen, brick.color, brick.rect, border_radius=3)

        pygame.draw.rect(self.screen, PADDLE_COLOR, self.paddle, border_radius=6)
        pygame.draw.circle(self.screen, BALL_COLOR,
                           (int(self.ball_x), int(self.ball_y)), BALL_RADIUS)

        if not self.game_over and not self.won:
            elapsed = pygame.time.get_ticks() - self.start_time
            remaining = self.start_delay - elapsed
            if remaining > 0:
                seconds = remaining // 1000 + 1
                count_text = self.big_font.render(str(seconds), True, WHITE)
                self.screen.blit(count_text, count_text.get_rect(
                    center=(WIDTH // 2, HEIGHT // 2 - 30)))

        if self.game_over or self.won:
            overlay = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
            overlay.fill((0, 0, 0, 160))
            self.screen.blit(overlay, (0, 0))
            msg = "You Win!" if self.won else "Game Over"
            color = (120, 240, 160) if self.won else (240, 120, 120)
            text = self.big_font.render(msg, True, color)
            self.screen.blit(text, text.get_rect(center=(WIDTH // 2, HEIGHT // 2 - 20)))
            sub = self.font.render(f"Final Score: {self.score}", True, WHITE)
            self.screen.blit(sub, sub.get_rect(center=(WIDTH // 2, HEIGHT // 2 + 20)))
            hint = self.small_font.render("Tap or press R to restart", True, (210, 210, 210))
            self.screen.blit(hint, hint.get_rect(center=(WIDTH // 2, HEIGHT // 2 + 50)))

    async def run(self):
        running = True
        while running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False

                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        running = False
                    elif event.key == pygame.K_r and (self.game_over or self.won):
                        self.reset()

                elif event.type == pygame.MOUSEBUTTONDOWN:
                    if self.game_over or self.won:
                        self.reset()
                    else:
                        self.touch_x = event.pos[0]
                elif event.type == pygame.MOUSEMOTION:
                    if pygame.mouse.get_pressed()[0]:
                        self.touch_x = event.pos[0]
                elif event.type == pygame.MOUSEBUTTONUP:
                    self.touch_x = None

                elif event.type == pygame.FINGERDOWN:
                    if self.game_over or self.won:
                        self.reset()
                    else:
                        self.touch_x = event.x * WIDTH
                elif event.type == pygame.FINGERMOTION:
                    self.touch_x = event.x * WIDTH
                elif event.type == pygame.FINGERUP:
                    self.touch_x = None

            self.update()
            self.draw()
            pygame.display.flip()
            self.clock.tick(60)
            await asyncio.sleep(0)


async def main():
    pygame.init()
    game = Game()
    await game.run()
    pygame.quit()


asyncio.run(main())
