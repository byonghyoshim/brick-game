import asyncio
import random

import pygame

BOARD_SIZE = 10
CELL_SIZE = 40
MARGIN = 20
TOP_MARGIN = 80
BOTTOM_MARGIN = 140
BOARD_PIXEL = BOARD_SIZE * CELL_SIZE
WINDOW_WIDTH = BOARD_PIXEL + MARGIN * 2
WINDOW_HEIGHT = BOARD_PIXEL + TOP_MARGIN + BOTTOM_MARGIN

WHITE = (250, 250, 250)
BLACK = (30, 30, 30)
GRID_BG = (220, 220, 230)
GRID_LINE = (180, 180, 190)

BLOCK_COLORS = [
    (231, 76, 60),
    (52, 152, 219),
    (46, 204, 113),
    (230, 126, 34),
    (155, 89, 182),
    (241, 196, 15),
    (26, 188, 156),
]

SHAPES = [
    [(0, 0)],
    [(0, 0), (0, 1)],
    [(0, 0), (1, 0)],
    [(0, 0), (0, 1), (0, 2)],
    [(0, 0), (1, 0), (2, 0)],
    [(0, 0), (0, 1), (0, 2), (0, 3)],
    [(0, 0), (1, 0), (2, 0), (3, 0)],
    [(0, 0), (0, 1), (1, 0), (1, 1)],
    [(0, 0), (0, 1), (1, 0)],
    [(0, 0), (0, 1), (1, 1)],
    [(0, 0), (1, 0), (1, 1)],
    [(0, 1), (1, 0), (1, 1)],
    [(0, 0), (0, 1), (0, 2), (1, 0), (2, 0)],
    [(0, 0), (0, 1), (0, 2), (1, 2), (2, 2)],
    [(0, 0), (1, 0), (2, 0), (2, 1), (2, 2)],
    [(0, 0), (0, 1), (0, 2), (1, 0), (1, 1), (1, 2), (2, 0), (2, 1), (2, 2)],
]

AUTHOR_NAME = "Made by Byonghyo"


class Game:
    def __init__(self):
        self.screen = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))
        pygame.display.set_caption("10x10 Block Puzzle")
        self.clock = pygame.time.Clock()
        self.font = pygame.font.SysFont("arial", 28)
        self.big_font = pygame.font.SysFont("arial", 40, bold=True)
        self.small_font = pygame.font.SysFont("arial", 18)
        self.author_font = pygame.font.SysFont("arial", 16, bold=True)
        self.reset()

    def reset(self):
        self.board = [[None] * BOARD_SIZE for _ in range(BOARD_SIZE)]
        self.score = 0
        self.game_over = False
        self.dragging = False
        self.drag_offset = (0, 0)
        self.spawn_block()

    def spawn_block(self):
        shape = random.choice(SHAPES)
        color = random.choice(BLOCK_COLORS)
        self.current_block = {"shape": shape, "color": color}
        self.reset_block_position()

    def reset_block_position(self):
        shape = self.current_block["shape"]
        cols = max(c for _, c in shape) + 1
        x = MARGIN + (BOARD_PIXEL - cols * CELL_SIZE) // 2
        y = TOP_MARGIN + BOARD_PIXEL + 30
        self.block_pos = [x, y]

    def board_cell_rect(self, r, c):
        return pygame.Rect(
            MARGIN + c * CELL_SIZE,
            TOP_MARGIN + r * CELL_SIZE,
            CELL_SIZE, CELL_SIZE
        )

    def get_grid_pos_from_block(self):
        bx, by = self.block_pos
        col = round((bx - MARGIN) / CELL_SIZE)
        row = round((by - TOP_MARGIN) / CELL_SIZE)
        return row, col

    def can_place(self, row, col):
        for dr, dc in self.current_block["shape"]:
            r, c = row + dr, col + dc
            if not (0 <= r < BOARD_SIZE and 0 <= c < BOARD_SIZE):
                return False
            if self.board[r][c] is not None:
                return False
        return True

    def place_block(self, row, col):
        color = self.current_block["color"]
        for dr, dc in self.current_block["shape"]:
            self.board[row + dr][col + dc] = color

    def clear_lines(self):
        rows_full = [r for r in range(BOARD_SIZE)
                     if all(self.board[r][c] is not None for c in range(BOARD_SIZE))]
        cols_full = [c for c in range(BOARD_SIZE)
                     if all(self.board[r][c] is not None for r in range(BOARD_SIZE))]
        for r in rows_full:
            for c in range(BOARD_SIZE):
                self.board[r][c] = None
        for c in cols_full:
            for r in range(BOARD_SIZE):
                self.board[r][c] = None
        self.score += (len(rows_full) + len(cols_full)) * 10

    def can_place_anywhere(self):
        for r in range(BOARD_SIZE):
            for c in range(BOARD_SIZE):
                if self.can_place(r, c):
                    return True
        return False

    def handle_mouse_down(self, pos):
        if self.game_over:
            return
        x, y = pos
        bx, by = self.block_pos
        for dr, dc in self.current_block["shape"]:
            cx = bx + dc * CELL_SIZE
            cy = by + dr * CELL_SIZE
            if cx <= x < cx + CELL_SIZE and cy <= y < cy + CELL_SIZE:
                self.dragging = True
                self.drag_offset = (x - bx, y - by)
                return
        # Allow tapping anywhere on the spawn block area to start dragging,
        # which is more touch-friendly.
        shape = self.current_block["shape"]
        rows = max(r for r, _ in shape) + 1
        cols = max(c for _, c in shape) + 1
        bw = cols * CELL_SIZE
        bh = rows * CELL_SIZE
        if bx <= x < bx + bw and by <= y < by + bh:
            self.dragging = True
            self.drag_offset = (x - bx, y - by)

    def handle_mouse_up(self, pos):
        if not self.dragging:
            return
        self.dragging = False
        row, col = self.get_grid_pos_from_block()
        if self.can_place(row, col):
            self.place_block(row, col)
            self.clear_lines()
            self.spawn_block()
            if not self.can_place_anywhere():
                self.game_over = True
        else:
            self.reset_block_position()

    def handle_mouse_motion(self, pos):
        if self.dragging:
            x, y = pos
            self.block_pos = [x - self.drag_offset[0], y - self.drag_offset[1]]

    def draw(self):
        self.screen.fill(WHITE)

        score_text = self.big_font.render(f"Score: {self.score}", True, BLACK)
        self.screen.blit(score_text, (MARGIN, 20))

        author_text = self.author_font.render(AUTHOR_NAME, True, (120, 120, 120))
        self.screen.blit(author_text,
                         (WINDOW_WIDTH - author_text.get_width() - MARGIN, 28))

        for r in range(BOARD_SIZE):
            for c in range(BOARD_SIZE):
                rect = self.board_cell_rect(r, c)
                color = self.board[r][c] if self.board[r][c] else GRID_BG
                pygame.draw.rect(self.screen, color, rect)
                pygame.draw.rect(self.screen, GRID_LINE, rect, 1)

        if self.dragging and not self.game_over:
            self.draw_ghost()

        if not self.game_over:
            self.draw_block(self.block_pos[0], self.block_pos[1])

        if self.game_over:
            overlay = pygame.Surface((WINDOW_WIDTH, WINDOW_HEIGHT), pygame.SRCALPHA)
            overlay.fill((0, 0, 0, 150))
            self.screen.blit(overlay, (0, 0))
            text = self.big_font.render("Game Over", True, (255, 255, 255))
            text_rect = text.get_rect(
                center=(WINDOW_WIDTH // 2, WINDOW_HEIGHT // 2 - 20))
            self.screen.blit(text, text_rect)
            score_msg = self.font.render(f"Final Score: {self.score}", True, (255, 255, 255))
            sm_rect = score_msg.get_rect(
                center=(WINDOW_WIDTH // 2, WINDOW_HEIGHT // 2 + 20))
            self.screen.blit(score_msg, sm_rect)
            hint = self.small_font.render("Tap or press R to restart", True, (220, 220, 220))
            hint_rect = hint.get_rect(
                center=(WINDOW_WIDTH // 2, WINDOW_HEIGHT // 2 + 55))
            self.screen.blit(hint, hint_rect)

    def draw_block(self, x, y):
        shape = self.current_block["shape"]
        color = self.current_block["color"]
        for dr, dc in shape:
            rect = pygame.Rect(x + dc * CELL_SIZE, y + dr * CELL_SIZE,
                               CELL_SIZE, CELL_SIZE)
            pygame.draw.rect(self.screen, color, rect, border_radius=4)
            pygame.draw.rect(self.screen, BLACK, rect, 1, border_radius=4)

    def draw_ghost(self):
        row, col = self.get_grid_pos_from_block()
        valid = self.can_place(row, col)
        ghost_color = (120, 200, 120, 120) if valid else (220, 100, 100, 120)
        ghost_surf = pygame.Surface((CELL_SIZE, CELL_SIZE), pygame.SRCALPHA)
        ghost_surf.fill(ghost_color)
        for dr, dc in self.current_block["shape"]:
            r, c = row + dr, col + dc
            if 0 <= r < BOARD_SIZE and 0 <= c < BOARD_SIZE:
                rect = self.board_cell_rect(r, c)
                self.screen.blit(ghost_surf, rect.topleft)

    async def run(self):
        running = True
        while running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    if self.game_over:
                        self.reset()
                    else:
                        self.handle_mouse_down(event.pos)
                elif event.type == pygame.MOUSEBUTTONUP and event.button == 1:
                    self.handle_mouse_up(event.pos)
                elif event.type == pygame.MOUSEMOTION:
                    self.handle_mouse_motion(event.pos)
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_r and self.game_over:
                        self.reset()

            self.draw()
            pygame.display.flip()
            self.clock.tick(60)
            await asyncio.sleep(0)


async def main():
    pygame.init()
    game = Game()
    await game.run()
    pygame.quit()


asyncio.run(main())
